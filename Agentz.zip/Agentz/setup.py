from setuptools import setup, find_packages

setup(
    name="agentix",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "langchain>=0.1.0",
        "langgraph>=0.0.10",
        "pandas>=2.0.0",
        "openai>=1.0.0",
        "python-dotenv>=1.0.0",
        "pydantic>=2.0.0",
        "streamlit>=1.30.0",
        "requests>=2.31.0"
    ],
    author="Your Name",
    author_email="your.email@example.com",
    description="A tool for creating and managing ReAct agents using LangChain",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/agentix",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
) 