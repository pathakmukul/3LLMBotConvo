import streamlit as st
from agentix.core import AgentiX
from agentix.types import UserRequest
from agentix.graph_agent import AgentState
from typing import Dict, Any, List
from langchain_core.messages import BaseMessage
import json

def display_react_process(msg):
    """Display a ReAct thinking process step."""
    try:
        content = json.loads(msg.content)
        if all(k in content for k in ["thought", "action", "action_input"]):
            st.markdown("🤔 **Thought:**")
            st.markdown(f"> {content['thought']}")
            st.markdown("🎯 **Action:**")
            st.markdown(f"> {content['action']}")
            st.markdown("📥 **Action Input:**")
            st.markdown(f"> {content['action_input']}")
            return True
    except:
        pass
    return False

def display_messages(messages):
    """Display message history in a structured way."""
    for msg in messages:
        if msg.type == "human":
            st.markdown("🧑‍💻 **User:**")
            st.markdown(f"> {msg.content}")
        elif msg.type == "function":
            # Try to display as ReAct process first
            if not display_react_process(msg):
                st.markdown("🔧 **Tool Output:**")
                try:
                    content = json.loads(msg.content)
                    st.json(content)
                except:
                    st.code(msg.content)
        else:
            st.markdown("🤖 **Agent:**")
            st.markdown(f"> {msg.content}")

def get_messages_for_stage(chunk: dict, stage: str) -> List[BaseMessage]:
    """Extract messages for a specific stage from the chunk."""
    if "messages" not in chunk:
        return []
    return [m for m in chunk["messages"] if stage in str(m.content)]

def main():
    st.title("AgentiX - ReAct Agent Creator")
    st.write("""
    Welcome to AgentiX! This tool helps you create and manage ReAct agents using LangGraph.
    Simply describe what you want your agent to do, and we'll either find an existing agent
    or create a new one for you.
    """)
    
    # Initialize AgentiX
    agentix = AgentiX()
    
    # Get user input
    description = st.text_area(
        "Describe what you want your agent to do:",
        height=100,
        placeholder="E.g., I want an agent that can scrape product prices from websites and compare them"
    )
    
    requirements = st.text_area(
        "List any specific requirements (one per line):",
        height=100,
        placeholder="E.g.,\nMust be able to handle multiple URLs\nShould compare prices accurately\nNeeds to handle different currencies"
    )
    
    if st.button("Create/Find Agent"):
        if not description:
            st.error("Please provide a description of what you want your agent to do.")
            return
            
        # Create user request
        request = UserRequest(
            description=description,
            requirements=requirements.split("\n") if requirements.strip() else []
        )
        
        # Create containers for workflow visualization
        workflow_container = st.container()
        with workflow_container:
            st.markdown("### 🔄 LangGraph Workflow Execution")
            
            # Create columns for workflow stages
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown("#### 1. Requirements Analysis")
                analysis_container = st.empty()
                react_analysis = st.container()
            
            with col2:
                st.markdown("#### 2. Agent Search")
                search_container = st.empty()
                react_search = st.container()
            
            with col3:
                st.markdown("#### 3. Agent Creation/Selection")
                creation_container = st.empty()
                react_creation = st.container()
            
            # Container for current state
            state_container = st.empty()
            
            try:
                # Initialize workflow state
                state = AgentState(
                    messages=[],
                    user_request=request,
                    current_tools=[],
                    agent_definition=None,
                    next_step="analyze_requirements"
                )
                
                # Execute workflow with state tracking
                for chunk in agentix.graph.stream_process(state):
                    # Update state display
                    state_container.json(chunk)
                    
                    # Update stage displays based on next_step
                    if chunk["next_step"] == "analyze_requirements":
                        analysis_container.info("🔄 Analyzing...")
                        with react_analysis:
                            display_messages(get_messages_for_stage(chunk, "analyze_requirements"))
                        if "current_tools" in chunk and chunk["current_tools"]:
                            analysis_container.success("✅ Tools identified")
                            analysis_container.json([t.model_dump() for t in chunk["current_tools"]])
                    
                    elif chunk["next_step"] == "search_existing":
                        search_container.info("🔍 Searching...")
                        with react_search:
                            display_messages(get_messages_for_stage(chunk, "search_agents"))
                        analysis_container.success("✅ Analysis complete")
                    
                    elif chunk["next_step"] == "create_agent":
                        creation_container.info("🔨 Creating new agent...")
                        with react_creation:
                            display_messages(get_messages_for_stage(chunk, "create_agent"))
                        search_container.warning("⚠️ No existing agent found")
                    
                    elif chunk["next_step"] == "end":
                        if chunk["agent_definition"] and chunk["agent_definition"].agent_name.startswith("agent_"):
                            creation_container.success("✅ New agent created")
                        else:
                            creation_container.success("✅ Existing agent found")
                            search_container.success("✅ Match found")
                
                # Get final agent definition
                agent_def = chunk.get("agent_definition")
                
                if agent_def is None:
                    st.error("Failed to create or find an agent. Please try again.")
                    return
                
                # Show success message
                is_new_agent = agent_def.agent_name.startswith("agent_")
                st.success(f"{'Created' if is_new_agent else 'Found'} agent: {agent_def.agent_name}")
                
                # Show complete message history
                with st.expander("🔄 Complete Workflow History", expanded=True):
                    display_messages(chunk.get("messages", []))
                
                # Show agent details in an expander
                with st.expander("📋 Agent Details", expanded=True):
                    st.markdown(f"**Description:** {agent_def.agent_description}")
                    st.markdown("**Tools:**")
                    for tool in agent_def.tools:
                        st.markdown(f"- **{tool.name}**: {tool.description}")
                    
                    st.markdown("**System Prompt:**")
                    st.code(agent_def.agent_prompt, language="text")
                
                # Show generated code
                with st.expander("💻 Generated Code", expanded=False):
                    code = agentix.get_agent_code(agent_def)
                    st.code(code, language="python")
                    
                    st.download_button(
                        label="📥 Download Code",
                        data=code,
                        file_name=f"{agent_def.agent_name}.py",
                        mime="text/plain"
                    )
                
                # Add usage example
                with st.expander("📚 Usage Example", expanded=False):
                    st.markdown("""
                    ### How to use this agent:
                    
                    1. **Save the code** above to a Python file (e.g., `agent.py`)
                    2. **Install requirements** if not already installed:
                       ```bash
                       pip install langchain langchain-openai python-dotenv
                       ```
                    3. **Set up environment variables** in a `.env` file:
                       ```
                       OPENAI_API_KEY=your-api-key-here
                       ```
                    4. **Run the agent**:
                       ```python
                       response = agent.run("Your query here")
                       print(response)
                       ```
                    """)
            
            except Exception as e:
                st.error(f"Error during workflow execution: {str(e)}")
                raise e

if __name__ == "__main__":
    main() 